<?php

namespace Facades\App\Helpers;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Helpers\Json
 */
class Json extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'App\Helpers\Json';
    }
}
