<?php $__env->startSection('title', 'Create new record'); ?>

<?php $__env->startSection('main'); ?>
    <h1>Create new record</h1>
    <form action="/admin/records" method="post">
        <?php echo $__env->make('admin.records.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_after'); ?>
    <?php echo $__env->make('admin.records.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/records/create.blade.php ENDPATH**/ ?>