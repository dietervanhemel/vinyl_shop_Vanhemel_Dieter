
<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <p><?php echo session()->get('success'); ?></p>
    </div>
<?php endif; ?>


<?php if(session()->has('danger')): ?>
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <p><?php echo session()->get('danger'); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/shared/alert.blade.php ENDPATH**/ ?>