<?php $__env->startSection('title', "Edit record: $record->artist - $record->title"); ?>

<?php $__env->startSection('main'); ?>
    <h1>Update record</h1>
    <form action="/admin/records/<?php echo e($record->id); ?>" method="post">
        <?php echo method_field('put'); ?>
        <?php echo $__env->make('admin.records.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_after'); ?>
    <?php echo $__env->make('admin.records.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/records/edit.blade.php ENDPATH**/ ?>