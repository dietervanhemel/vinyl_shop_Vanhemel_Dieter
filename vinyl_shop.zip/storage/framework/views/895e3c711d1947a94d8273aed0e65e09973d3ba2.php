<?php $__env->startSection('Shop - Alternative listening'); ?>
<?php $__env->startSection('main'); ?>
    <h1>Shop - Alternative listening</h1>
<div class="container">
    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e($genre->name); ?></h2>
    <ul>
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($genre->id == $record->genre_id): ?>
               <li><a href="#"><?php echo e($record->artist); ?> - <?php echo e($record->title); ?></a> | Price: € <?php echo e($record->price); ?> | Stock: <?php echo e($record->stock); ?></li>
           <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/shop/shop_alt.blade.php ENDPATH**/ ?>