<?php $__env->startSection('title', 'Update password'); ?>

<?php $__env->startSection('main'); ?>
    <h1>New password</h1>
    <?php echo $__env->make('shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="/user/password" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="current_password">Current password</label>
            <input type="password" name="current_password" id="current_password"
                   class="form-control <?php if ($errors->has('current_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('current_password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Current password"
                   value="<?php echo e(old('current_password')); ?>"
                   required>
            <?php if ($errors->has('current_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('current_password'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="password">New password</label>
            <input type="password" name="password" id="password"
                   class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="New password"
                   value="<?php echo e(old('password')); ?>"
                   minlength="8"
                   required>
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="password_confirmation">Confirm new password</label>
            <input type="password" name="password_confirmation" id="password_confirmation"
                   class="form-control"
                   placeholder="Confirm new password"
                   value="<?php echo e(old('password_confirmation')); ?>"
                   minlength="8"
                   required>
        </div>
        <button type="submit" class="btn btn-success">Update password</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/user/password.blade.php ENDPATH**/ ?>