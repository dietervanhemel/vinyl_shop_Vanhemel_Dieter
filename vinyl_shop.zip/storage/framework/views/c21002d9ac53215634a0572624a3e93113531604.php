<?php $__env->startSection('title', 'Edit user'); ?>

<?php $__env->startSection('main'); ?>
    <h1>Edit User: <?php echo e($user->name); ?></h1>
    <form action="/admin/users/<?php echo e($user->id); ?>" method="post">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name"
                   class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Name"
                   minlength="3"
                   required
                   value="<?php echo e(old('name', $user->name)); ?>">
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" name="email" id="email"
                   class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Email"
                   minlength="3"
                   required
                   value="<?php echo e(old('email', $user->email)); ?>">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-check form-check-inline">
            <input type="checkbox" name="active" id="active" class="form-check-input"
                   <?php if($user->active): ?> checked <?php endif; ?>>
            <label for="active" class="form-check-label">Active</label>
        </div>
        <div class="form-check form-check-inline">
            <input type="checkbox" name="admin" id="admin" class="form-check-input"
                   <?php if($user->admin): ?> checked <?php endif; ?>>
            <label for="admin" class="form-check-label">Admin</label>
        </div>
        <button type="submit" class="btn btn-success mt-2">Save user</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>