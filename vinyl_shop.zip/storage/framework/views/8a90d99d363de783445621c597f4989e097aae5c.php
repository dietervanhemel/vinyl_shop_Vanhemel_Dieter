<?php $__env->startSection('main'); ?>
    <h1>The Vinyl Shop</h1>
    <p>Welcome to the website of The Vinyl Shop, a large online store with lots of (classic) vinyl records.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/home.blade.php ENDPATH**/ ?>