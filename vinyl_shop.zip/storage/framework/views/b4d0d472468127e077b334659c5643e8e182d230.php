<?php $__env->startSection('main'); ?>
    <h1>Contact us</h1>
    <?php echo $__env->make('shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(!session()->has('success')): ?>
        <form action="/contact-us" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" id="name"
                       class="form-control <?php echo e($errors->first('name') ? 'is-invalid' : ''); ?>"
                       placeholder="Your name"
                       required
                       value="<?php echo e(old('name')); ?>">
                <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email"
                       class="form-control <?php echo e($errors->first('email') ? 'is-invalid' : ''); ?>"
                       placeholder="Your email"
                       required
                       value="<?php echo e(old('email')); ?>">
                <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
            </div>
            <div class="form-group">
                <label for="contact">Contact</label>
                <select
                    class="form-control <?php echo e($errors->first('contact') ? 'is-invalid' : ''); ?>"
                    id="contact"
                    name="contact"
                    required>
                    <option value="">Select a contact</option>
                    <option value="info">Info</option>
                    <option value="billing">Billing</option>
                    <option value="support">Support</option>
                </select>
                <div class="invalid-feedback"><?php echo e($errors->first('contact')); ?></div>
            </div>
            <div class="form-group">
                <label for="message">Message</label>
                <textarea name="message" id="message" rows="5"
                          class="form-control <?php echo e($errors->first('message') ? 'is-invalid' : ''); ?>"
                          placeholder="Your message"
                          required
                          minlength="10"><?php echo e(old('message')); ?></textarea>
                <div class="invalid-feedback"><?php echo e($errors->first('message')); ?></div>
            </div>
            <button type="submit" class="btn btn-success">Send Message</button>
        </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/contact.blade.php ENDPATH**/ ?>