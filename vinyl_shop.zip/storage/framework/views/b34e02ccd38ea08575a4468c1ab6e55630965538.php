<?php $__env->startSection('main'); ?>
    <h3 class="text-center my-5">419 | <span class="text-black-50"><?php echo e($exception->getMessage() ?: 'CSRF token mismatch'); ?></span></h3>
    <p class="text-center my-5">
        <a href="/" class="btn btn-outline-secondary btn-sm mr-2">
            <i class="fas fa-home mr-1"></i>home
        </a>
        <a href="#!" class="btn btn-outline-secondary btn-sm ml-2" id="back">
            <i class="fas fa-undo mr-1"></i>back
        </a>
    </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_after'); ?>
    <script>
        // Go back to the previous page
        $('#back').click(function () {
            window.history.back();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/errors/419.blade.php ENDPATH**/ ?>