<?php $__env->startComponent('mail::message'); ?>
# Dear <?php echo e($request->name); ?>,
Thanks for you message.<br>
We'll contact you as soon as possible.

<hr>
<b>Your name:</b> <?php echo e($request->name); ?><br>
<b>Your email:</b> <?php echo e($request->email); ?><br>
<b>Your message:</b><br><?php echo e($request->message); ?>


Thanks,<br>
<?php echo e(env('APP_NAME')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/email/contact.blade.php ENDPATH**/ ?>