<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="shortcut icon" href="<?php echo asset('assets/icons/favicon.ico'); ?>">
    <title><?php echo $__env->yieldContent('title', 'The Vinyl Shop'); ?></title>
    <?php echo $__env->yieldContent('css_after'); ?>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('script_after'); ?>
</head>
<body>
<?php echo $__env->make('shared.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="container mt-3">
    <?php echo $__env->yieldContent('main', 'Page under construction ...'); ?>
</main>
<?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('script_after'); ?>
<?php if(env('APP_DEBUG')): ?>
    <script>
        $('form').attr('novalidate', 'true');
    </script>
<?php endif; ?>
</body>
</html>
<?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/layouts/template.blade.php ENDPATH**/ ?>