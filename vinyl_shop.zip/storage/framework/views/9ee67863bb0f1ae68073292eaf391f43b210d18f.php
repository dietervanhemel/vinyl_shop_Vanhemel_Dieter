<?php $__env->startSection('title', 'Create new genre'); ?>

<?php $__env->startSection('main'); ?>
    <h1>Create new genre</h1>
    <form action="/admin/genres" method="post">
        <?php echo $__env->make('admin.genres.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/genres/create.blade.php ENDPATH**/ ?>