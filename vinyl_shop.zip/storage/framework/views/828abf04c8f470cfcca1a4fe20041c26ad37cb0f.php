<?php echo csrf_field(); ?>
<div class="form-group">
    <label for="name">Name</label>
    <input type="text" name="name" id="name"
           class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
           placeholder="Name"
           minlength="3"
           required
           value="<?php echo e(old('name', $genre->name)); ?>">
    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<button type="submit" class="btn btn-success">Save genre</button>
<?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/genres/form.blade.php ENDPATH**/ ?>