<?php $__env->startSection('title', 'Edit genre'); ?>

<?php $__env->startSection('main'); ?>
    <h1>Edit genre: <?php echo e($genre->name); ?></h1>
    <form action="/admin/genres/<?php echo e($genre->id); ?>" method="post">
        <?php echo method_field('put'); ?>
        <?php echo $__env->make('admin.genres.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name"
                   class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Name"
                   minlength="3"
                   required
                   value="<?php echo e(old('name', $genre->name)); ?>">
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <button type="submit" class="btn btn-success">Save genre</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/genres/edit.blade.php ENDPATH**/ ?>