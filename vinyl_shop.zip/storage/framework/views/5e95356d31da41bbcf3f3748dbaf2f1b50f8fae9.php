<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-8">
        <div class="form-group">
            <label for="artist">Artist</label>
            <input type="text" name="artist" id="artist"
                   class="form-control <?php if ($errors->has('artist')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('artist'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Artist name"
                   required
                   value="<?php echo e(old('artist', $record->artist)); ?>">
            <?php if ($errors->has('artist')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('artist'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="artist_mbid">Artist MusicBrainz ID</label>
            <input type="text" name="artist_mbid" id="artist_mbid"
                   class="form-control <?php if ($errors->has('artist_mbid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('artist_mbid'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Artist MusicBrainz ID (36 characters)"
                   required minlength="36" maxlength="36"
                   value="<?php echo e(old('artist_mbid', $record->artist_mbid)); ?>">
            <?php if ($errors->has('artist_mbid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('artist_mbid'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" name="title" id="title"
                   class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Record title"
                   required
                   value="<?php echo e(old('title', $record->title)); ?>">
            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="title_mbid">Title MusicBrainz ID</label>
            <input type="text" name="title_mbid" id="title_mbid"
                   class="form-control <?php if ($errors->has('title_mbid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title_mbid'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Title MusicBrainz ID (36 characters)"
                   required minlength="36" maxlength="36"
                   value="<?php echo e(old('title_mbid', $record->title_mbid)); ?>">
            <?php if ($errors->has('title_mbid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title_mbid'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="cover">Cover URL</label>
            <input type="text" name="cover" id="cover"
                   class="form-control <?php if ($errors->has('cover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cover'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Cover URL"
                   value="<?php echo e(old('cover', $record->cover)); ?>">
            <?php if ($errors->has('cover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cover'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="number" name="price" id="price"
                   class="form-control <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Price"
                   required
                   step="0.01"
                   value="<?php echo e(old('price', $record->price)); ?>">
            <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="stock">Stock</label>
            <input type="number" name="stock" id="stock"
                   class="form-control <?php if ($errors->has('stock')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stock'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                   placeholder="Items in stock"
                   required
                   value="<?php echo e(old('stock', $record->stock)); ?>">
            <?php if ($errors->has('stock')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('stock'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
            <label for="genre_id">Genre</label>
            <select name="genre_id" id="genre_id"
                    class="custom-select <?php if ($errors->has('genre_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('genre_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                    required>
                <option value="">Select a genre</option>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($genre->id); ?>"
                        <?php echo e((old('genre_id', $record->genre_id) ==  $genre->id ? 'selected' : '')); ?>><?php echo e(ucfirst($genre->name)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if ($errors->has('genre_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('genre_id'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <p>
            <button type="submit" id="submit" class="btn btn-success">Save record</button>
        </p>
    </div>
    <div class="col-4">
        <img src="/assets/vinyl.png" alt="cover" class="img-thumbnail" id="coverImage">
    </div>
</div>
<?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/records/form.blade.php ENDPATH**/ ?>