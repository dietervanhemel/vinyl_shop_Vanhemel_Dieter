<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('main'); ?>
    <h1>Users</h1>
    <?php echo $__env->make('shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="get" action="/admin/users" id="searchForm">
        <div class="row">
            <div class="col-sm-8 mb-2">
                <label for="user_name">Filter Name or Email</label>
                <input type="text" class="form-control" name="user_name" id="user_name"
                       value="<?php echo e(request()->user_name); ?>"
                       placeholder="Filter Name Or Email">
            </div>
            <div class="col-sm-4 mb-2">
                <label for="sort_by">Sort by</label>
                <select class="form-control" name="sort_by" id="sort_by">
                    <option value="0"
                        <?php echo e((request()->sort_by ==  0? 'selected' : '')); ?>>Name (A => Z)
                    </option>
                    <option value="1"
                        <?php echo e((request()->sort_by ==  1? 'selected' : '')); ?>>Name (Z => A)
                    </option>
                    <option value="2"
                        <?php echo e((request()->sort_by ==  2? 'selected' : '')); ?>>Email (A => Z)
                    </option>
                    <option value="3"
                        <?php echo e((request()->sort_by ==  3? 'selected' : '')); ?>>Email (Z => A)
                    </option>
                    <option value="4"
                        <?php echo e((request()->sort_by ==  4? 'selected' : '')); ?>>Not active
                    </option>
                    <option value="5"
                        <?php echo e((request()->sort_by ==  5? 'selected' : '')); ?>>Admin
                    </option>
                </select>
            </div>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Active</th>
                <th>Admin</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php if($user->active): ?> <i class="fas fa-check"></i> <?php endif; ?></td>
                    <td><?php if($user->admin): ?> <i class="fas fa-check"></i> <?php endif; ?></td>
                    <td data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>">
                        <form action="/admin/users/<?php echo e($user->id); ?>" method="post" id="delete_form">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="btn-group btn-group-sm ">
                                <a href="/admin/users/<?php echo e($user->id); ?>/edit" class="btn btn-outline-success <?php if(Auth::user()->name == $user->name): ?> disabled <?php endif; ?>"
                                   data-toggle="tooltip"
                                   title="Edit <?php echo e($user->name); ?>">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button type="button" class="btn btn-outline-danger btn-delete"
                                        data-toggle="tooltip"
                                        title="Delete <?php echo e($user->name); ?>"
                                        data-user="<?php echo e($user->name); ?>"
                                        <?php if(Auth::user()->name == $user->name): ?> disabled <?php endif; ?>>
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </div>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if($users->count() == 0): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            Can't find any user with <b>'<?php echo e(request()->user_name); ?>'</b>
            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php echo e($users->links()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_after'); ?>
    <script>
        $(function () {
            // submit form when leaving text field 'artist'
            $('#user_name').blur(function () {
                $('#searchForm').submit();
            });
            // submit form when changing dropdown list 'genre_id'
            $('#sort_by').change(function () {
                $('#searchForm').submit();
            });

            $('tbody').on('click', '.btn-delete', function () {
                // Get data attributes from td tag
                let id = $(this).closest('td').data('id');
                let name = $(this).closest('td').data('name');

                // Set some values for Noty
                let text = `<p>Delete the user <b>${name}</b>?</p>`;
                let type = 'warning';
                let btnText = 'Delete user';
                let btnClass = 'btn-success';

                // Show Noty
                let modal = new Noty({
                    timeout: false,
                    layout: 'center',
                    modal: true,
                    type: type,
                    text: text,
                    buttons: [
                        Noty.button(btnText, `btn ${btnClass}`, function () {
                            // Delete user and close modal
                            $('#delete_form').submit();
                            modal.close();
                        }),
                        Noty.button('Cancel', 'btn btn-secondary ml-2', function () {
                            modal.close();
                        })
                    ]
                }).show();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/admin/users/index.blade.php ENDPATH**/ ?>