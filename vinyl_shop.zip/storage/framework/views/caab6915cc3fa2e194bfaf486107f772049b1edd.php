<?php $__env->startSection('title', 'Shop'); ?>

<?php $__env->startSection('main'); ?>
    <h1>Shop</h1>
    <form method="get" action="/shop" id="searchForm">
        <div class="row">
            <div class="col-sm-6 mb-2">
                <input type="text" class="form-control" name="artist" id="artist"
                       value="" placeholder="Filter Artist Or Record">
            </div>
            <div class="col-sm-4 mb-2">
                <select class="form-control" name="genre_id">
                    <option value="%">All genres</option>
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($genre->id); ?>"
                            <?php echo e((request()->genre_id ==  $genre->id ? 'selected' : '')); ?>><?php echo e($genre->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>



            </div>
            <div class="col-sm-2 mb-2">
                <button type="submit" class="btn btn-success btn-block">Search</button>
            </div>
        </div>
    </form>
    <hr>
    <?php if($records->count() == 0): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            Can't find any artist or album with <b>'<?php echo e(request()->artist); ?>'</b> for this genre
            <button type="button" class="close" data-dismiss="alert">
                <span>&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php echo e($records->links()); ?>

    <div class="row">
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-4 col-lg-3 mb-3">
                <div class="card data-id="<?php echo e($record->id); ?>">
                    <img class="card-img-top" src="/assets/vinyl.png" data-src="<?php echo e($record->cover); ?>" alt="<?php echo e($record->artist); ?> - <?php echo e($record->title); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($record->artist); ?></h5>
                        <p class="card-text"><?php echo e($record->title); ?></p>
                        <a href="shop/<?php echo e($record->id); ?>" class="btn btn-outline-info btn-sm btn-block weg">Show details</a>
                    </div>
                    <div class="card-footer d-flex justify-content-between">
                        <p><?php echo e($record->genre->name); ?></p>
                        <p>
                            € <?php echo e(number_format($record->price,2)); ?>

                            <span class="ml-3 badge badge-success"><?php echo e($record->stock); ?></span>
                        </p>
                    </div>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($records->links()); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_after'); ?>
    <script>
        $(function () {
            // Get record id and redirect to the detail page
            $('.card').click(function () {
                record_id = $(this).data('id');
                $(location).attr('href', `/shop/${record_id}`); //OR $(location).attr('href', '/shop/' + record_id);
            });
            // Replace vinyl.png with real cover
            $('.card img').each(function () {
                $(this).attr('src', $(this).data('src'));
            });
            // Add shadow to card on hover
            $('.card').hover(function () {
                $(this).addClass('shadow');
            }, function () {
                $(this).removeClass('shadow');
            });
            // submit form when leaving text field 'artist'
            $('#artist').blur(function () {
                $('#searchForm').submit();
            });
            // submit form when changing dropdown list 'genre_id'
            $('#genre_id').change(function () {
                $('#searchForm').submit();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/shop/index.blade.php ENDPATH**/ ?>