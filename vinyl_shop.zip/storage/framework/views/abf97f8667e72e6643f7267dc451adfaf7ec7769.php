<?php $__env->startSection('main'); ?>
    <h3 class="text-center my-5">404 | <span class="text-black-50">Not Found</span></h3>
    <p class="text-center my-5">
        <a href="/" class="btn btn-outline-secondary btn-sm mr-2">
            <i class="fas fa-home mr-1"></i>home
        </a>
        <a href="#!" class="btn btn-outline-secondary btn-sm ml-2" id="back">
            <i class="fas fa-undo mr-1"></i>back
        </a>
    </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_after'); ?>
    <script>
        // Go back to the previous page
        $('#back').click(function () {
            window.history.back();
        });
        // Remove the right navigation
        $('nav .ml-auto').hide();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/errors/404.blade.php ENDPATH**/ ?>