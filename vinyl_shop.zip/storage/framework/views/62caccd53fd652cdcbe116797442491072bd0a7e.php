<!-- Copyright Section -->
<footer class="footer footer-expand-md footer-light  text-right">
    <div class="container">
        <hr>
        <div><p>The vinyl Shop - &copy; <?php echo date("Y"); ?></p></div>
    </div>
</footer>

<?php /**PATH /home/vagrant/code/vinyl_shop/resources/views/shared/footer.blade.php ENDPATH**/ ?>