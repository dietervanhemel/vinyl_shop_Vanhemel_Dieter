# vinyl_shop_Vanhemel_Dieter
## Project info
Laravel project, implemented during the course 'Webapplicaties in PHP', 2ITF, Thomas More Kempen. 
## Student info
- **Name:** Dieter Vanhemel
- **Number:** r0670539
- **Group:** 2 IOT
# vinyl_shop_Vanhemel_Dieter
